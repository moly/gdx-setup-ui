package @{PACKAGE_NAME};

import org.flixel.FlxDesktopApplication;

public class Main
 {
	public static void main(String[] args) 
	{
		new FlxDesktopApplication(new @{MAINCLASS_NAME}(), @{STAGE_WIDTH}, @{STAGE_HEIGHT});
	}
}
