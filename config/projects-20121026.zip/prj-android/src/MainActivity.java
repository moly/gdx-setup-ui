package @{PACKAGE_NAME};

import org.flixel.FlxAndroidApplication;

public class MainActivity extends FlxAndroidApplication 
{
    public MainActivity()
	{
		super(new @{MAINCLASS_NAME}());
	}
}