package @{PACKAGE_NAME};

import org.flixel.FlxGame;

public class @{MAINCLASS_NAME} extends FlxGame
{
	public @{MAINCLASS_NAME}()
	{
		super(@{GAME_WIDTH}, @{GAME_HEIGHT}, PlayState.class, @{ZOOM}, 50, 50, false, @{STAGE_WIDTH}, @{STAGE_HEIGHT});
	}
}
