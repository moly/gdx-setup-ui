package @{PACKAGE_NAME};

import org.flixel.FlxGame;

public class @{MAINCLASS_NAME} extends FlxGame
{
	public @{MAINCLASS_NAME}()
	{
		super(@{GAMEWIDTH}, @{GAMEHEIGHT}, PlayState.class, @{ZOOM}, 50, 50, false, @{STAGEWIDTH}, @{STAGEHEIGHT});
	}
}
